0.3.0
* Added `tidy_msg()` to turn a `msg` object into a `tibble`

0.2.1
* Fixed issue #2

0.2.0
* Switched to C library

0.1.0 
* Initial release
